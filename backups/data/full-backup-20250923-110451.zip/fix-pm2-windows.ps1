# Windows PM2问题修复脚本
# 解决npm命令反复启动cmd的问题

param(
    [Parameter(Mandatory=$false)]
    [string]$ConfigPath = "ecosystem.config.js"
)

Write-Host "🔧 修复Windows下PM2的npm命令问题..." -ForegroundColor Green

# 1. 停止所有PM2进程
Write-Host "🛑 停止现有PM2进程..." -ForegroundColor Yellow
try {
    pm2 delete all
    Write-Host "✅ 已停止所有PM2进程" -ForegroundColor Green
} catch {
    Write-Host "⚠️ 没有运行中的PM2进程" -ForegroundColor Yellow
}

# 2. 清理PM2
Write-Host "🧹 清理PM2缓存..." -ForegroundColor Yellow
try {
    pm2 kill
    pm2 flush
    Write-Host "✅ PM2缓存已清理" -ForegroundColor Green
} catch {
    Write-Host "⚠️ PM2清理完成" -ForegroundColor Yellow
}

# 3. 检查npm路径
Write-Host "🔍 检查npm路径..." -ForegroundColor Yellow
$npmPath = Get-Command npm -ErrorAction SilentlyContinue
if ($npmPath) {
    Write-Host "✅ 找到npm: $($npmPath.Source)" -ForegroundColor Green
    $env:NPM_PATH = $npmPath.Source
} else {
    Write-Host "❌ 未找到npm命令" -ForegroundColor Red
    exit 1
}

# 4. 运行修复脚本
Write-Host "🔧 运行配置修复..." -ForegroundColor Yellow
if (Test-Path "config/pm2-windows-fix.js") {
    node config/pm2-windows-fix.js
} else {
    Write-Host "❌ 修复脚本不存在: config/pm2-windows-fix.js" -ForegroundColor Red
}

# 5. 重新启动PM2
Write-Host "🚀 重新启动PM2服务..." -ForegroundColor Green
if (Test-Path $ConfigPath) {
    try {
        pm2 start $ConfigPath
        pm2 save
        Write-Host "✅ PM2服务已启动" -ForegroundColor Green
        
        # 显示状态
        Write-Host "📊 当前PM2状态:" -ForegroundColor Cyan
        pm2 status
    } catch {
        Write-Host "❌ PM2启动失败: $_" -ForegroundColor Red
    }
} else {
    Write-Host "❌ 配置文件不存在: $ConfigPath" -ForegroundColor Red
}

Write-Host ""
Write-Host "🎉 修复完成！" -ForegroundColor Green
Write-Host "如果问题仍然存在，请检查:" -ForegroundColor Yellow
Write-Host "  1. 应用的package.json中是否存在对应的scripts" -ForegroundColor White
Write-Host "  2. 工作目录路径是否正确" -ForegroundColor White
Write-Host "  3. 是否有权限访问应用目录" -ForegroundColor White
