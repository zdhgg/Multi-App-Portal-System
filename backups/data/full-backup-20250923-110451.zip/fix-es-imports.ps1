# ES模块导入修复脚本
# 批量修复detection-api/dist目录下所有.js文件中的相对导入问题

Write-Host "🔧 开始修复ES模块导入问题..." -ForegroundColor Yellow

$distPath = "detection-api\dist"
$fixedCount = 0
$totalFiles = 0

# 获取所有.js文件
$jsFiles = Get-ChildItem -Path $distPath -Recurse -Filter "*.js"
$totalFiles = $jsFiles.Count

Write-Host "📁 找到 $totalFiles 个JavaScript文件" -ForegroundColor Cyan

foreach ($file in $jsFiles) {
    $content = Get-Content $file.FullName -Raw
    $originalContent = $content
    
    # 修复相对导入：添加.js扩展名
    # 匹配模式：import ... from './xxx' 或 import ... from '../xxx'
    $pattern = "import\s+([^']+)\s+from\s+'(\.[^']+)'"

    $content = [regex]::Replace($content, $pattern, {
        param($match)
        $importStatement = $match.Groups[1].Value
        $importPath = $match.Groups[2].Value

        # 如果路径不以.js结尾，添加.js
        if (-not $importPath.EndsWith('.js')) {
            return "import $importStatement from '$importPath.js'"
        }
        return $match.Value
    })

    # 修复路径别名导入
    # @utils/xxx -> ../utils/xxx.js
    $content = $content -replace "import\s+([^']+)\s+from\s+'@utils/([^']+)'", "import `$1 from '../utils/`$2.js'"
    # @services/xxx -> ../services/xxx.js
    $content = $content -replace "import\s+([^']+)\s+from\s+'@services/([^']+)'", "import `$1 from '../services/`$2.js'"
    # @models/xxx -> ../models/xxx.js
    $content = $content -replace "import\s+([^']+)\s+from\s+'@models/([^']+)'", "import `$1 from '../models/`$2.js'"
    # @routes/xxx -> ../routes/xxx.js
    $content = $content -replace "import\s+([^']+)\s+from\s+'@routes/([^']+)'", "import `$1 from '../routes/`$2.js'"
    # @middleware/xxx -> ../middleware/xxx.js
    $content = $content -replace "import\s+([^']+)\s+from\s+'@middleware/([^']+)'", "import `$1 from '../middleware/`$2.js'"
    # @types/xxx -> ../types/xxx.js
    $content = $content -replace "import\s+([^']+)\s+from\s+'@types/([^']+)'", "import `$1 from '../types/`$2.js'"
    
    # 如果内容有变化，写回文件
    if ($content -ne $originalContent) {
        Set-Content -Path $file.FullName -Value $content -NoNewline
        $fixedCount++
        Write-Host "✅ 修复: $($file.FullName)" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "🎯 修复完成!" -ForegroundColor Green
Write-Host "📊 统计信息:" -ForegroundColor Cyan
Write-Host "   - 总文件数: $totalFiles" -ForegroundColor White
Write-Host "   - 修复文件数: $fixedCount" -ForegroundColor White
Write-Host "   - 未修改文件数: $($totalFiles - $fixedCount)" -ForegroundColor White

if ($fixedCount -gt 0) {
    Write-Host ""
    Write-Host "🚀 正在重启PM2服务..." -ForegroundColor Yellow
    pm2 restart portal-api
    
    Write-Host ""
    Write-Host "⏳ 等待服务启动..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
    
    Write-Host ""
    Write-Host "🔍 检查服务状态..." -ForegroundColor Yellow
    pm2 list
} else {
    Write-Host ""
    Write-Host "ℹ️  没有文件需要修复" -ForegroundColor Blue
}
