# 智能多Web应用门户系统 - 实时监控仪表板
# 提供PM2进程、系统资源、服务健康状态的实时监控
# 作者: Augment Agent
# 版本: 2.0.0

param(
    [int]$RefreshInterval = 3,
    [int]$BackendPort = 8001,
    [int]$FrontendPort = 3000,
    [switch]$EnableAutoRecovery,
    [switch]$Quiet,
    [switch]$Help
)

# ============================================================================
# 全局配置和变量
# ============================================================================

$SCRIPT_VERSION = "2.0.0"
$SCRIPT_NAME = "智能多Web应用门户系统监控仪表板"

# 路径配置
$PROJECT_ROOT = $PSScriptRoot

# 导入统一日志系统
$LOGS_SCRIPT = Join-Path $PROJECT_ROOT "logs.ps1"
if (Test-Path $LOGS_SCRIPT) {
    . $LOGS_SCRIPT
}

# 导入配置管理系统
$CONFIG_SCRIPT = Join-Path $PROJECT_ROOT "config.ps1"
if (Test-Path $CONFIG_SCRIPT) {
    . $CONFIG_SCRIPT

    # 从统一配置系统加载配置
    if (Get-Command Get-ConfigForScript -ErrorAction SilentlyContinue) {
        try {
            $monitorConfig = Get-ConfigForScript "monitor"
            $RefreshInterval = $monitorConfig.RefreshInterval
            $BackendPort = $monitorConfig.BackendPort
            $FrontendPort = $monitorConfig.FrontendPort
            $EnableAutoRecovery = $monitorConfig.EnableAutoRecovery
        } catch {
            Write-Host "配置加载失败，使用默认值: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
}

# API端点配置
$API_BASE = "http://localhost:$BackendPort/api"
$HEALTH_ENDPOINT = "http://localhost:$BackendPort/health"

# 监控数据缓存
$script:MonitorData = @{
    PM2Processes = @()
    PM2Stats = @{}
    SystemResources = @{}
    HealthStatus = @{}
    RecoveryStatus = @{}
    LastUpdate = Get-Date
    Errors = @()
}

# 恢复系统状态
$script:RecoveryEnabled = $EnableAutoRecovery
$script:LastRecoveryCheck = $null
$script:RecoveryStats = @{
    TotalRecoveries = 0
    SuccessfulRecoveries = 0
    LastRecoveryTime = $null
}

# 控制台状态
$script:IsRunning = $true
$script:ShowDetails = $false
$script:ShowLogs = $false
$script:LogLines = 20

# ============================================================================
# 工具函数
# ============================================================================

function Write-ColorText {
    param(
        [string]$Text,
        [ConsoleColor]$Color = "White",
        [switch]$NoNewline
    )
    
    $originalColor = $Host.UI.RawUI.ForegroundColor
    $Host.UI.RawUI.ForegroundColor = $Color
    if ($NoNewline) {
        Write-Host $Text -NoNewline
    } else {
        Write-Host $Text
    }
    $Host.UI.RawUI.ForegroundColor = $originalColor
}

function Clear-ConsoleArea {
    param([int]$Lines = 50)
    
    for ($i = 0; $i -lt $Lines; $i++) {
        Write-Host (" " * 120)
    }
}

function Get-ProgressBar {
    param(
        [double]$Percentage,
        [int]$Width = 10,
        [string]$FilledChar = "█",
        [string]$EmptyChar = "░"
    )
    
    $filled = [math]::Floor($Percentage / 100 * $Width)
    $empty = $Width - $filled
    
    return ($FilledChar * $filled) + ($EmptyChar * $empty)
}

function Format-Bytes {
    param([long]$Bytes)
    
    if ($Bytes -ge 1GB) {
        return "{0:N1} GB" -f ($Bytes / 1GB)
    } elseif ($Bytes -ge 1MB) {
        return "{0:N1} MB" -f ($Bytes / 1MB)
    } elseif ($Bytes -ge 1KB) {
        return "{0:N1} KB" -f ($Bytes / 1KB)
    } else {
        return "$Bytes B"
    }
}

function Format-Duration {
    param([double]$Seconds)
    
    $timespan = [TimeSpan]::FromSeconds($Seconds)
    if ($timespan.Days -gt 0) {
        return "{0}d {1}h {2}m" -f $timespan.Days, $timespan.Hours, $timespan.Minutes
    } elseif ($timespan.Hours -gt 0) {
        return "{0}h {1}m" -f $timespan.Hours, $timespan.Minutes
    } else {
        return "{0}m {1}s" -f $timespan.Minutes, $timespan.Seconds
    }
}

# ============================================================================
# 数据收集函数
# ============================================================================

function Get-PM2ProcessData {
    try {
        $response = Invoke-RestMethod -Uri "$API_BASE/pm2/processes" -Method Get -TimeoutSec 5
        if ($response.success) {
            $script:MonitorData.PM2Processes = $response.data
        }
    } catch {
        $script:MonitorData.Errors += "PM2进程数据获取失败: $($_.Exception.Message)"
    }
}

function Get-PM2StatsData {
    try {
        $response = Invoke-RestMethod -Uri "$API_BASE/pm2/stats" -Method Get -TimeoutSec 5
        if ($response.success) {
            $script:MonitorData.PM2Stats = $response.data
        }
    } catch {
        $script:MonitorData.Errors += "PM2统计数据获取失败: $($_.Exception.Message)"
    }
}

function Get-SystemResourceData {
    try {
        # 获取CPU使用率
        $cpuCounter = Get-Counter "\Processor(_Total)\% Processor Time" -SampleInterval 1 -MaxSamples 1
        $cpuUsage = [math]::Round(100 - $cpuCounter.CounterSamples[0].CookedValue, 1)
        
        # 获取内存使用率
        $totalMemory = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory
        $availableMemory = (Get-Counter "\Memory\Available Bytes").CounterSamples[0].CookedValue
        $usedMemory = $totalMemory - $availableMemory
        $memoryUsage = [math]::Round(($usedMemory / $totalMemory) * 100, 1)
        
        $script:MonitorData.SystemResources = @{
            CPU = @{
                Usage = $cpuUsage
                Cores = (Get-CimInstance Win32_ComputerSystem).NumberOfProcessors
            }
            Memory = @{
                Total = $totalMemory
                Used = $usedMemory
                Available = $availableMemory
                Usage = $memoryUsage
            }
            Uptime = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
        }
    } catch {
        $script:MonitorData.Errors += "系统资源数据获取失败: $($_.Exception.Message)"
    }
}

function Get-HealthStatusData {
    try {
        # 后端健康检查
        $backendHealth = Invoke-RestMethod -Uri $HEALTH_ENDPOINT -Method Get -TimeoutSec 5
        
        # 前端健康检查
        $frontendHealthy = $false
        try {
            $frontendResponse = Invoke-WebRequest -Uri "http://localhost:$FrontendPort" -Method Get -TimeoutSec 5
            $frontendHealthy = $frontendResponse.StatusCode -eq 200
        } catch {
            $frontendHealthy = $false
        }
        
        $script:MonitorData.HealthStatus = @{
            Backend = @{
                Status = $backendHealth.status
                Uptime = $backendHealth.uptime
                Memory = $backendHealth.memory
                Version = $backendHealth.version
            }
            Frontend = @{
                Status = if ($frontendHealthy) { "healthy" } else { "unhealthy" }
            }
            WebSocket = @{
                Status = "connected"  # 简化处理
            }
        }
    } catch {
        $script:MonitorData.Errors += "健康状态数据获取失败: $($_.Exception.Message)"
    }
}

function Update-MonitorData {
    # 清除旧错误
    $script:MonitorData.Errors = @()
    
    # 并行收集数据
    $jobs = @()
    $jobs += Start-Job -ScriptBlock { param($api) Invoke-RestMethod -Uri "$api/pm2/processes" -Method Get -TimeoutSec 5 } -ArgumentList $API_BASE
    $jobs += Start-Job -ScriptBlock { param($api) Invoke-RestMethod -Uri "$api/pm2/stats" -Method Get -TimeoutSec 5 } -ArgumentList $API_BASE
    $jobs += Start-Job -ScriptBlock { param($health) Invoke-RestMethod -Uri $health -Method Get -TimeoutSec 5 } -ArgumentList $HEALTH_ENDPOINT
    
    # 等待作业完成
    $results = $jobs | Wait-Job -Timeout 10 | Receive-Job
    $jobs | Remove-Job -Force
    
    # 处理结果
    if ($results.Count -ge 1 -and $results[0].success) {
        $script:MonitorData.PM2Processes = $results[0].data
    }
    if ($results.Count -ge 2 -and $results[1].success) {
        $script:MonitorData.PM2Stats = $results[1].data
    }
    if ($results.Count -ge 3) {
        $script:MonitorData.HealthStatus.Backend = $results[2]
    }
    
    # 获取系统资源（同步）
    Get-SystemResourceData
    
    # 更新时间戳
    $script:MonitorData.LastUpdate = Get-Date
}

# ============================================================================
# 显示函数
# ============================================================================

function Show-Header {
    Write-Host ""
    Write-ColorText "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -Color Cyan
    Write-ColorText "  $SCRIPT_NAME v$SCRIPT_VERSION" -Color Cyan
    Write-ColorText "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -Color Cyan
    Write-ColorText "  最后更新: $($script:MonitorData.LastUpdate.ToString('yyyy-MM-dd HH:mm:ss'))  |  刷新间隔: ${RefreshInterval}秒" -Color Gray
    Write-Host ""
}

function Show-Help {
    Clear-Host
    Write-ColorText "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -Color Cyan
    Write-ColorText "  $SCRIPT_NAME v$SCRIPT_VERSION - 帮助文档" -Color Cyan
    Write-ColorText "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -Color Cyan
    Write-Host ""
    Write-ColorText "📖 使用方法:" -Color Yellow
    Write-Host "  .\monitor.ps1 [参数]"
    Write-Host ""
    Write-ColorText "⚙️ 参数:" -Color Yellow
    Write-Host "  -RefreshInterval <秒>  刷新间隔 (默认: 3秒)"
    Write-Host "  -BackendPort <端口>    后端端口 (默认: 8001)"
    Write-Host "  -FrontendPort <端口>   前端端口 (默认: 3000)"
    Write-Host "  -Quiet                 静默模式"
    Write-Host "  -Help                  显示帮助"
    Write-Host ""
    Write-ColorText "🎮 交互操作:" -Color Yellow
    Write-Host "  [R] 手动刷新数据"
    Write-Host "  [D] 切换详细视图"
    Write-Host "  [L] 切换日志视图"
    Write-Host "  [G] 日志管理"
    Write-Host "  [A] 切换自动恢复"
    Write-Host "  [F] 手动恢复"
    Write-Host "  [H] 显示帮助"
    Write-Host "  [Q] 退出监控"
    Write-Host ""
    Write-ColorText "💡 使用示例:" -Color Yellow
    Write-Host "  .\monitor.ps1                    # 默认设置启动监控"
    Write-Host "  .\monitor.ps1 -RefreshInterval 5 # 5秒刷新间隔"
    Write-Host ""
    Write-ColorText "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -Color Cyan
    Write-Host ""
    Write-Host "按任意键返回监控界面..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Show-SystemOverview {
    Write-ColorText "📊 系统概览" -Color Yellow

    $resources = $script:MonitorData.SystemResources
    if ($resources -and $resources.Count -gt 0 -and $resources.CPU) {
        $cpuBar = Get-ProgressBar -Percentage $resources.CPU.Usage -Width 10
        $memoryBar = Get-ProgressBar -Percentage $resources.Memory.Usage -Width 10

        Write-Host "├─ CPU: " -NoNewline
        $cpuColor = if ($resources.CPU.Usage -gt 80) { "Red" } elseif ($resources.CPU.Usage -gt 60) { "Yellow" } else { "Green" }
        Write-ColorText $cpuBar -Color $cpuColor -NoNewline
        Write-Host " $($resources.CPU.Usage)%"

        Write-Host "├─ 内存: " -NoNewline
        $memoryColor = if ($resources.Memory.Usage -gt 80) { "Red" } elseif ($resources.Memory.Usage -gt 60) { "Yellow" } else { "Green" }
        Write-ColorText $memoryBar -Color $memoryColor -NoNewline
        Write-Host " $($resources.Memory.Usage)% ($(Format-Bytes $resources.Memory.Used)/$(Format-Bytes $resources.Memory.Total))"

        Write-Host "└─ CPU核心: $($resources.CPU.Cores)个"
    } else {
        Write-ColorText "├─ 数据加载中..." -Color Gray
        Write-ColorText "├─ CPU: 检测中..." -Color Gray
        Write-ColorText "└─ 内存: 检测中..." -Color Gray
    }
    Write-Host ""
}

function Show-ProcessStatus {
    Write-ColorText "🔄 进程状态" -Color Yellow

    $processes = $script:MonitorData.PM2Processes
    if ($processes -and $processes.Count -gt 0) {
        foreach ($process in $processes) {
            $status = if ($process.pm2_env -and $process.pm2_env.status) { $process.pm2_env.status } else { "unknown" }

            $statusIcon = switch ($status) {
                "online" { "●" }
                "stopped" { "○" }
                "errored" { "✗" }
                default { "?" }
            }

            $statusColor = switch ($status) {
                "online" { "Green" }
                "stopped" { "Gray" }
                "errored" { "Red" }
                default { "Yellow" }
            }

            $processName = if ($process.name) { $process.name } else { "未知进程" }
            Write-Host "├─ $processName " -NoNewline
            Write-ColorText "[$statusIcon]" -Color $statusColor -NoNewline
            Write-Host " $status"

            if ($script:ShowDetails) {
                $processPid = if ($process.pid) { $process.pid } else { "N/A" }
                $processCpu = if ($process.monit -and $process.monit.cpu) { "$($process.monit.cpu)%" } else { "N/A" }
                $processMemory = if ($process.monit -and $process.monit.memory) { Format-Bytes $process.monit.memory } else { "N/A" }
                $processRestarts = if ($process.pm2_env -and $process.pm2_env.restart_time) { $process.pm2_env.restart_time } else { "0" }

                Write-Host "│  ├─ PID: $processPid"
                Write-Host "│  ├─ CPU: $processCpu"
                Write-Host "│  ├─ 内存: $processMemory"
                Write-Host "│  ├─ 重启次数: $processRestarts"

                if ($process.pm2_env -and $process.pm2_env.pm_uptime) {
                    try {
                        $uptime = (Get-Date) - [DateTime]$process.pm2_env.pm_uptime
                        Write-Host "│  └─ 运行时间: $(Format-Duration $uptime.TotalSeconds)"
                    } catch {
                        Write-Host "│  └─ 运行时间: N/A"
                    }
                } else {
                    Write-Host "│  └─ 运行时间: N/A"
                }
            } else {
                $processPid = if ($process.pid) { $process.pid } else { "N/A" }
                $processCpu = if ($process.monit -and $process.monit.cpu) { "$($process.monit.cpu)%" } else { "N/A" }
                $processMemory = if ($process.monit -and $process.monit.memory) { Format-Bytes $process.monit.memory } else { "N/A" }
                $processRestarts = if ($process.pm2_env -and $process.pm2_env.restart_time) { $process.pm2_env.restart_time } else { "0" }

                Write-Host "│  PID: $processPid  CPU: $processCpu  内存: $processMemory  重启: ${processRestarts}次"
            }
        }
    } else {
        Write-ColorText "├─ 无运行中的进程" -Color Gray
        Write-ColorText "└─ 请检查PM2服务状态" -Color Gray
    }
    Write-Host ""
}

function Show-HealthStatus {
    Write-ColorText "💚 服务健康状态" -Color Yellow

    $health = $script:MonitorData.HealthStatus
    if ($health.Count -gt 0) {
        # 后端状态
        $backendIcon = if ($health.Backend.Status -eq "ok") { "✅" } else { "❌" }
        $backendStatus = if ($health.Backend.Status -eq "ok") { "健康" } else { "异常" }
        Write-Host "├─ 后端API: $backendIcon $backendStatus"

        if ($script:ShowDetails -and $health.Backend) {
            Write-Host "│  ├─ 版本: $($health.Backend.Version)"
            Write-Host "│  ├─ 运行时间: $(Format-Duration $health.Backend.Uptime)"
            Write-Host "│  └─ 内存使用: $(Format-Bytes $health.Backend.Memory.heapUsed)/$(Format-Bytes $health.Backend.Memory.heapTotal)"
        }

        # 前端状态
        $frontendIcon = if ($health.Frontend.Status -eq "healthy") { "✅" } else { "❌" }
        $frontendStatus = if ($health.Frontend.Status -eq "healthy") { "健康" } else { "异常" }
        Write-Host "├─ 前端服务: $frontendIcon $frontendStatus"

        # WebSocket状态
        $wsIcon = if ($health.WebSocket.Status -eq "connected") { "✅" } else { "❌" }
        $wsStatus = if ($health.WebSocket.Status -eq "connected") { "连接" } else { "断开" }
        Write-Host "└─ WebSocket: $wsIcon $wsStatus"
    } else {
        Write-ColorText "  健康状态检查中..." -Color Gray
    }
    Write-Host ""
}

function Show-RecentLogs {
    Write-ColorText "📝 最新日志" -Color Yellow

    if ($script:ShowLogs) {
        try {
            # 尝试获取PM2日志
            $processes = $script:MonitorData.PM2Processes
            if ($processes.Count -gt 0) {
                $mainProcess = $processes[0]
                $response = Invoke-RestMethod -Uri "$API_BASE/pm2/processes/$($mainProcess.name)/logs?lines=$script:LogLines" -Method Get -TimeoutSec 5

                if ($response.success -and $response.data.logs) {
                    $logs = $response.data.logs | Select-Object -Last $script:LogLines
                    foreach ($log in $logs) {
                        $timestamp = $log.timestamp
                        $message = $log.message
                        Write-Host "├─ [$timestamp] $message"
                    }
                } else {
                    Write-ColorText "  暂无日志数据" -Color Gray
                }
            } else {
                Write-ColorText "  无可用进程日志" -Color Gray
            }
        } catch {
            Write-ColorText "  日志获取失败: $($_.Exception.Message)" -Color Red
        }
    } else {
        # 显示简化的系统事件
        $events = @(
            "[$(Get-Date -Format 'HH:mm:ss')] 监控系统运行中",
            "[$(Get-Date -Format 'HH:mm:ss')] 数据刷新正常",
            "[$(Get-Date -Format 'HH:mm:ss')] 所有服务监控中"
        )

        foreach ($event in $events) {
            Write-Host "├─ $event"
        }
    }
    Write-Host ""
}

function Show-RecoveryStatus {
    Write-ColorText "🔧 自动恢复状态" -Color Yellow

    $recoveryStatus = if ($script:RecoveryEnabled) { "✅ 启用" } else { "❌ 禁用" }
    $recoveryColor = if ($script:RecoveryEnabled) { "Green" } else { "Red" }

    Write-Host "├─ 自动恢复: " -NoNewline
    Write-ColorText $recoveryStatus -Color $recoveryColor

    if ($script:RecoveryStats.TotalRecoveries -gt 0) {
        Write-Host "├─ 总恢复次数: $($script:RecoveryStats.TotalRecoveries)"
        Write-Host "├─ 成功恢复: $($script:RecoveryStats.SuccessfulRecoveries)"
        if ($script:RecoveryStats.LastRecoveryTime) {
            Write-Host "└─ 最后恢复: $($script:RecoveryStats.LastRecoveryTime.ToString('HH:mm:ss'))"
        } else {
            Write-Host "└─ 最后恢复: 无"
        }
    } else {
        Write-Host "└─ 恢复历史: 无"
    }
    Write-Host ""
}

function Show-Controls {
    Write-ColorText "🎮 操作: " -Color Yellow -NoNewline
    $recoveryIndicator = if ($script:RecoveryEnabled) { "[A]恢复✅" } else { "[A]恢复❌" }
    Write-Host "[R]刷新 [D]详细 [L]日志 [G]日志管理 $recoveryIndicator [F]手动恢复 [H]帮助 [Q]退出"
    Write-Host ""
}

function Show-ErrorMessages {
    if ($script:MonitorData.Errors.Count -gt 0) {
        Write-ColorText "⚠️ 错误信息:" -Color Red
        foreach ($error in $script:MonitorData.Errors) {
            Write-ColorText "  • $error" -Color Red
        }
        Write-Host ""
    }
}

function Show-MonitorDashboard {
    Clear-Host
    Show-Header

    # 创建两列布局
    $leftColumn = @()
    $rightColumn = @()

    # 左列：系统概览和进程状态
    $leftColumn += "📊 系统概览"
    $leftColumn += Show-SystemOverview
    $leftColumn += "🔄 进程状态"
    $leftColumn += Show-ProcessStatus

    # 右列：健康状态和日志
    $rightColumn += "💚 服务健康状态"
    $rightColumn += Show-HealthStatus
    $rightColumn += "📝 最新日志"
    $rightColumn += Show-RecentLogs

    # 显示左列
    Show-SystemOverview
    Show-ProcessStatus

    # 显示右列
    Show-HealthStatus
    Show-RecentLogs

    # 显示恢复状态
    Show-RecoveryStatus

    # 显示错误信息
    Show-ErrorMessages

    # 显示控制说明
    Show-Controls
}

# ============================================================================
# 交互控制函数
# ============================================================================

function Handle-KeyInput {
    if ($Host.UI.RawUI.KeyAvailable) {
        $key = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

        switch ($key.Character.ToString().ToUpper()) {
            'R' {
                # 手动刷新
                Update-MonitorData
                return $true
            }
            'D' {
                # 切换详细视图
                $script:ShowDetails = -not $script:ShowDetails
                return $true
            }
            'L' {
                # 切换日志视图
                $script:ShowLogs = -not $script:ShowLogs
                return $true
            }
            'G' {
                # 日志管理
                Invoke-LogManagement
                return $true
            }
            'A' {
                # 切换自动恢复
                $script:RecoveryEnabled = -not $script:RecoveryEnabled
                Write-ColorText "自动恢复已$(if ($script:RecoveryEnabled) { '启用' } else { '禁用' })" -Color $(if ($script:RecoveryEnabled) { "Green" } else { "Red" })
                Start-Sleep -Seconds 1
                return $true
            }
            'F' {
                # 手动恢复
                Invoke-ManualRecovery
                return $true
            }
            'H' {
                # 显示帮助
                Show-Help
                return $true
            }
            'Q' {
                # 退出
                $script:IsRunning = $false
                return $false
            }
            default {
                return $true
            }
        }
    }
    return $true
}

function Invoke-ManualRecovery {
    Write-ColorText "🔧 执行手动恢复..." -Color Yellow

    # 检查recovery.ps1是否存在
    $recoveryScript = Join-Path $PSScriptRoot "recovery.ps1"
    if (-not (Test-Path $recoveryScript)) {
        Write-ColorText "❌ 恢复脚本不存在: recovery.ps1" -Color Red
        Start-Sleep -Seconds 2
        return
    }

    try {
        # 执行恢复脚本
        Write-ColorText "正在执行系统恢复..." -Color Yellow
        $result = & $recoveryScript -Mode recover -BackendPort $BackendPort -FrontendPort $FrontendPort -VerboseOutput

        # 更新恢复统计
        $script:RecoveryStats.TotalRecoveries++
        $script:RecoveryStats.LastRecoveryTime = Get-Date

        # 检查恢复结果（简化处理）
        if ($LASTEXITCODE -eq 0) {
            $script:RecoveryStats.SuccessfulRecoveries++
            Write-ColorText "✅ 手动恢复完成" -Color Green
        } else {
            Write-ColorText "⚠️ 恢复过程中出现问题" -Color Yellow
        }

        # 刷新监控数据
        Update-MonitorData

    } catch {
        Write-ColorText "❌ 恢复执行失败: $($_.Exception.Message)" -Color Red
    }

    Start-Sleep -Seconds 3
}

function Invoke-LogManagement {
    Write-ColorText "📝 日志管理菜单" -Color Yellow
    Write-Host ""
    Write-Host "请选择日志管理操作:"
    Write-Host "  [1] 查看最新日志"
    Write-Host "  [2] 搜索日志内容"
    Write-Host "  [3] 查看日志统计"
    Write-Host "  [4] 清理日志文件"
    Write-Host "  [5] 实时监控日志"
    Write-Host "  [0] 返回监控界面"
    Write-Host ""

    $choice = Read-Host "请输入选择 (0-5)"

    switch ($choice) {
        "1" {
            Write-ColorText "查看最新日志..." -Color Cyan
            if (Get-Command Show-LogEntries -ErrorAction SilentlyContinue) {
                Show-LogEntries "all" "ALL" "" "1h" 20
            } else {
                Write-ColorText "日志系统未加载" -Color Red
            }
            Read-Host "按回车键继续"
        }
        "2" {
            $searchTerm = Read-Host "请输入搜索关键词"
            if ($searchTerm -and (Get-Command Search-LogEntries -ErrorAction SilentlyContinue)) {
                Search-LogEntries $searchTerm "all" "ALL" "24h" 30
            } else {
                Write-ColorText "搜索失败或日志系统未加载" -Color Red
            }
            Read-Host "按回车键继续"
        }
        "3" {
            Write-ColorText "生成日志统计..." -Color Cyan
            if (Get-Command Show-LogStatistics -ErrorAction SilentlyContinue) {
                Show-LogStatistics "all" "24h"
            } else {
                Write-ColorText "日志系统未加载" -Color Red
            }
            Read-Host "按回车键继续"
        }
        "4" {
            Write-ColorText "⚠️ 警告：此操作将清理日志文件" -Color Yellow
            $confirm = Read-Host "确定要继续吗？(y/N)"
            if ($confirm -eq "y" -or $confirm -eq "Y") {
                if (Get-Command Clear-LogFiles -ErrorAction SilentlyContinue) {
                    Clear-LogFiles "all" -Archive:$true -Force:$true
                } else {
                    Write-ColorText "日志系统未加载" -Color Red
                }
            }
            Read-Host "按回车键继续"
        }
        "5" {
            Write-ColorText "启动实时日志监控（按Ctrl+C退出）..." -Color Cyan
            if (Get-Command Start-LogTail -ErrorAction SilentlyContinue) {
                Start-LogTail "all" "ALL"
            } else {
                Write-ColorText "日志系统未加载" -Color Red
                Read-Host "按回车键继续"
            }
        }
        "0" {
            # 返回监控界面
        }
        default {
            Write-ColorText "无效选择" -Color Red
            Start-Sleep -Seconds 1
        }
    }
}

function Start-MonitorLoop {
    Write-Host "正在启动监控仪表板..." -ForegroundColor Green
    Write-Host "初始化数据收集..." -ForegroundColor Yellow

    # 初始数据收集
    Update-MonitorData

    Write-Host "监控仪表板已启动！按 Q 退出，按 H 查看帮助。" -ForegroundColor Green
    Start-Sleep -Seconds 2

    $lastRefresh = Get-Date

    while ($script:IsRunning) {
        # 检查是否需要刷新数据
        $now = Get-Date
        if (($now - $lastRefresh).TotalSeconds -ge $RefreshInterval) {
            Update-MonitorData
            $lastRefresh = $now
        }

        # 显示监控界面
        Show-MonitorDashboard

        # 处理用户输入
        $continue = Handle-KeyInput
        if (-not $continue) {
            break
        }

        # 短暂休眠以减少CPU使用
        Start-Sleep -Milliseconds 500
    }

    Write-Host ""
    Write-ColorText "监控仪表板已退出。" -Color Green
}

# ============================================================================
# 主函数
# ============================================================================

function Main {
    # 处理帮助请求
    if ($Help) {
        Show-Help
        return
    }

    # 检查依赖
    if (-not (Test-Path "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")) {
        Write-Error "需要PowerShell环境"
        return
    }

    # 验证端口参数
    if ($BackendPort -lt 1 -or $BackendPort -gt 65535) {
        Write-Error "无效的后端端口: $BackendPort"
        return
    }

    if ($FrontendPort -lt 1 -or $FrontendPort -gt 65535) {
        Write-Error "无效的前端端口: $FrontendPort"
        return
    }

    # 测试后端连接
    try {
        Write-Host "测试后端连接..." -ForegroundColor Yellow
        $testResponse = Invoke-RestMethod -Uri $HEALTH_ENDPOINT -Method Get -TimeoutSec 5
        Write-Host "✅ 后端连接正常" -ForegroundColor Green
    } catch {
        Write-Warning "⚠️ 后端连接失败: $($_.Exception.Message)"
        Write-Host "监控功能可能受限，但仍可查看系统资源信息。" -ForegroundColor Yellow

        $continue = Read-Host "是否继续启动监控? (y/N)"
        if ($continue -ne 'y' -and $continue -ne 'Y') {
            return
        }
    }

    # 设置控制台
    try {
        $Host.UI.RawUI.WindowTitle = "$SCRIPT_NAME v$SCRIPT_VERSION"
        $Host.UI.RawUI.CursorSize = 0  # 隐藏光标
    } catch {
        # 忽略控制台设置错误
    }

    # 注册清理函数
    Register-EngineEvent PowerShell.Exiting -Action {
        $script:IsRunning = $false
        try {
            $Host.UI.RawUI.CursorSize = 25  # 恢复光标
        } catch {}
    }

    # 启动监控循环
    try {
        Start-MonitorLoop
    } catch {
        Write-Error "监控过程中发生错误: $($_.Exception.Message)"
    } finally {
        # 恢复控制台设置
        try {
            $Host.UI.RawUI.CursorSize = 25
        } catch {}
    }
}

# 执行主函数
Main
