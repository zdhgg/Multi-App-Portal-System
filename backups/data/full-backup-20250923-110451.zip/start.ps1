# 智能多Web应用门户系统 - 统一启动脚本 v2.0
# 集成环境管理、依赖检查、健康监控、PM2部署等功能
# 作者: Augment Agent
# 版本: 2.0.0

param(
    # 环境选择
    [Parameter(Mandatory=$false)]
    [ValidateSet("dev", "development", "prod", "production")]
    [string]$Environment = "development",
    
    # 启动模式
    [Parameter(Mandatory=$false)]
    [ValidateSet("pm2", "dev", "development", "hybrid", "auto")]
    [string]$Mode = "auto",
    
    # 功能开关
    [switch]$SkipDependencyCheck,
    [switch]$SkipHealthCheck,
    [switch]$SkipBuild,
    [switch]$EnableAutoRecovery,
    [switch]$Force,
    [switch]$Quiet,
    [switch]$VerboseOutput,
    [switch]$DryRun,
    
    # 配置参数
    [int]$TimeoutSeconds = 30,
    [int]$BackendPort = 8001,
    [int]$FrontendPort = 3000,
    
    # 高级选项
    [switch]$ShowMenu,
    [switch]$Help
)

# ============================================================================
# 全局配置和常量
# ============================================================================

$SCRIPT_VERSION = "2.0.0"
$SCRIPT_NAME = "智能多Web应用门户系统统一启动器"

# 标准化环境名称
$ENV_NAME = switch ($Environment.ToLower()) {
    { $_ -in @("dev", "development") } { "development" }
    { $_ -in @("prod", "production") } { "production" }
}

# 标准化启动模式
$START_MODE = switch ($Mode.ToLower()) {
    { $_ -in @("dev", "development") } { "development" }
    "pm2" { "pm2" }
    "hybrid" { "hybrid" }
    "auto" { "auto" }
}

# 路径配置
$PROJECT_ROOT = $PSScriptRoot
$BACKEND_DIR = Join-Path $PROJECT_ROOT "detection-api"
$FRONTEND_DIR = Join-Path $PROJECT_ROOT "main-portal"

# 导入统一日志系统
$LOGS_SCRIPT = Join-Path $PROJECT_ROOT "logs.ps1"
if (Test-Path $LOGS_SCRIPT) {
    . $LOGS_SCRIPT
}

# 导入配置管理系统
$CONFIG_SCRIPT = Join-Path $PROJECT_ROOT "config.ps1"
if (Test-Path $CONFIG_SCRIPT) {
    . $CONFIG_SCRIPT
}

# 导入API管理系统
$API_SCRIPT = Join-Path $PROJECT_ROOT "api.ps1"
if (Test-Path $API_SCRIPT) {
    . $API_SCRIPT
}
$CONFIG_DIR = Join-Path $PROJECT_ROOT "config"
$SCRIPTS_DIR = Join-Path $PROJECT_ROOT "scripts"

# 健康检查配置
$HEALTH_CHECK_INTERVAL = 3
$MAX_RETRIES = 3

# ============================================================================
# 日志和输出函数
# ============================================================================

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO", "WARN", "ERROR", "DEBUG", "SUCCESS")]
        [string]$Level = "INFO",
        [string]$Component = "MAIN"
    )
    
    if ($Quiet -and $Level -notin @("ERROR", "WARN")) { return }
    if (-not $VerboseOutput -and $Level -eq "DEBUG") { return }
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $prefix = "[$timestamp] [$Component] [$Level]"
    
    $color = switch ($Level) {
        "INFO" { "White" }
        "SUCCESS" { "Green" }
        "WARN" { "Yellow" }
        "ERROR" { "Red" }
        "DEBUG" { "Cyan" }
        default { "Gray" }
    }
    
    Write-Host "$prefix $Message" -ForegroundColor $color
}

function Write-Success { param($Message, $Component = "MAIN") Write-Log $Message "SUCCESS" $Component }
function Write-Warning { param($Message, $Component = "MAIN") Write-Log $Message "WARN" $Component }
function Write-Error { param($Message, $Component = "MAIN") Write-Log $Message "ERROR" $Component }
function Write-Info { param($Message, $Component = "MAIN") Write-Log $Message "INFO" $Component }
function Write-Debug { param($Message, $Component = "MAIN") Write-Log $Message "DEBUG" $Component }

# ============================================================================
# 帮助和菜单函数
# ============================================================================

function Show-Help {
    Clear-Host
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
    Write-Host "  $SCRIPT_NAME v$SCRIPT_VERSION" -ForegroundColor Cyan
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "📖 使用方法:" -ForegroundColor Yellow
    Write-Host "  .\start.ps1 [参数]" -ForegroundColor White
    Write-Host ""
    Write-Host "🎯 主要参数:" -ForegroundColor Yellow
    Write-Host "  -Environment <env>    环境选择: dev|development|prod|production (默认: development)" -ForegroundColor White
    Write-Host "  -Mode <mode>          启动模式: pm2|dev|development|hybrid|auto (默认: auto)" -ForegroundColor White
    Write-Host ""
    Write-Host "🔧 功能开关:" -ForegroundColor Yellow
    Write-Host "  -SkipDependencyCheck  跳过依赖检查" -ForegroundColor White
    Write-Host "  -SkipHealthCheck      跳过健康检查" -ForegroundColor White
    Write-Host "  -SkipBuild            跳过构建步骤" -ForegroundColor White
    Write-Host "  -EnableAutoRecovery   启用自动恢复机制" -ForegroundColor White
    Write-Host "  -Force                强制启动（终止现有进程）" -ForegroundColor White
    Write-Host "  -Quiet                静默模式" -ForegroundColor White
    Write-Host "  -VerboseOutput        详细输出" -ForegroundColor White
    Write-Host "  -DryRun               模拟运行（不实际执行）" -ForegroundColor White
    Write-Host ""
    Write-Host "⚙️ 配置参数:" -ForegroundColor Yellow
    Write-Host "  -TimeoutSeconds <n>   健康检查超时时间 (默认: 30)" -ForegroundColor White
    Write-Host "  -BackendPort <port>   后端端口 (默认: 8001)" -ForegroundColor White
    Write-Host "  -FrontendPort <port>  前端端口 (默认: 3000)" -ForegroundColor White
    Write-Host ""
    Write-Host "🎮 交互选项:" -ForegroundColor Yellow
    Write-Host "  -ShowMenu             显示交互式菜单" -ForegroundColor White
    Write-Host "  -Help                 显示此帮助信息" -ForegroundColor White
    Write-Host ""
    Write-Host "💡 使用示例:" -ForegroundColor Yellow
    Write-Host "  .\start.ps1                                    # 自动模式启动开发环境" -ForegroundColor Green
    Write-Host "  .\start.ps1 -Environment production -Mode pm2  # PM2模式启动生产环境" -ForegroundColor Green
    Write-Host "  .\start.ps1 -ShowMenu                          # 显示交互式菜单" -ForegroundColor Green
    Write-Host "  .\start.ps1 -Mode dev -VerboseOutput           # 开发模式详细输出" -ForegroundColor Green
    Write-Host ""
    Write-Host "🔗 向后兼容:" -ForegroundColor Yellow
    Write-Host "  现有脚本仍可独立使用：enhanced-start.ps1、start-dev.ps1、deploy-pm2.ps1" -ForegroundColor Gray
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
}

function Show-InteractiveMenu {
    Clear-Host
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
    Write-Host "  $SCRIPT_NAME v$SCRIPT_VERSION" -ForegroundColor Cyan
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "🎮 请选择启动方式:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  [1] 🚀 快速开发启动 (推荐)" -ForegroundColor Green
    Write-Host "      • 开发环境 + 开发模式" -ForegroundColor Gray
    Write-Host "      • 热重载 + 详细日志" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [2] 🏭 生产环境部署" -ForegroundColor Blue
    Write-Host "      • 生产环境 + PM2模式" -ForegroundColor Gray
    Write-Host "      • 集群模式 + 性能优化" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [3] 🔧 自定义配置" -ForegroundColor Magenta
    Write-Host "      • 手动选择环境和模式" -ForegroundColor Gray
    Write-Host "      • 高级选项配置" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [4] 📊 系统状态检查" -ForegroundColor Cyan
    Write-Host "      • 检查依赖和服务状态" -ForegroundColor Gray
    Write-Host "      • 不启动服务" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [5] 📊 监控仪表板" -ForegroundColor Magenta
    Write-Host "      • 实时监控系统状态" -ForegroundColor Gray
    Write-Host "      • PM2进程和资源监控" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [6] 📝 日志管理" -ForegroundColor Green
    Write-Host "      • 查看和搜索日志" -ForegroundColor Gray
    Write-Host "      • 日志统计和清理" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [7] ⚙️ 配置管理" -ForegroundColor Magenta
    Write-Host "      • 系统配置管理" -ForegroundColor Gray
    Write-Host "      • 配置备份和恢复" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [8] 🔌 API接口管理" -ForegroundColor Blue
    Write-Host "      • API发现和注册" -ForegroundColor Gray
    Write-Host "      • API监控和测试" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  [9] 📖 查看帮助文档" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  [0] 🚪 退出" -ForegroundColor Red
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan

    $choice = Read-Host "请输入选择 (0-8)"
    
    switch ($choice) {
        "1" {
            Write-Info "选择: 快速开发启动" "MENU"
            return @{ Environment = "development"; Mode = "development"; Interactive = $true }
        }
        "2" {
            Write-Info "选择: 生产环境部署" "MENU"
            return @{ Environment = "production"; Mode = "pm2"; Interactive = $true }
        }
        "3" {
            return Get-CustomConfiguration
        }
        "4" {
            return @{ Environment = "development"; Mode = "check"; Interactive = $true }
        }
        "5" {
            Write-Info "启动监控仪表板..." "MENU"
            Start-MonitorDashboard
            return $null
        }
        "6" {
            Write-Info "启动日志管理..." "MENU"
            Start-LogManagement
            return $null
        }
        "7" {
            Write-Info "启动配置管理..." "MENU"
            Start-ConfigManagement
            return $null
        }
        "8" {
            Write-Info "启动API接口管理..." "MENU"
            Start-ApiManagement
            return $null
        }
        "9" {
            Show-Help
            return $null
        }
        "0" {
            Write-Info "退出启动器" "MENU"
            exit 0
        }
        default {
            Write-Warning "无效选择，请重新选择" "MENU"
            Start-Sleep -Seconds 1
            return Show-InteractiveMenu
        }
    }
}

function Get-CustomConfiguration {
    Write-Host ""
    Write-Host "🔧 自定义配置" -ForegroundColor Magenta
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Gray
    
    # 环境选择
    Write-Host ""
    Write-Host "📋 选择环境:" -ForegroundColor Yellow
    Write-Host "  [1] 开发环境 (development)" -ForegroundColor Green
    Write-Host "  [2] 生产环境 (production)" -ForegroundColor Blue
    $envChoice = Read-Host "请选择环境 (1-2, 默认: 1)"
    $selectedEnv = if ($envChoice -eq "2") { "production" } else { "development" }
    
    # 模式选择
    Write-Host ""
    Write-Host "🚀 选择启动模式:" -ForegroundColor Yellow
    Write-Host "  [1] 开发模式 (development) - 热重载" -ForegroundColor Green
    Write-Host "  [2] PM2模式 (pm2) - 进程管理" -ForegroundColor Blue
    Write-Host "  [3] 混合模式 (hybrid) - 前端开发+后端PM2" -ForegroundColor Magenta
    Write-Host "  [4] 自动模式 (auto) - 智能选择" -ForegroundColor Cyan
    $modeChoice = Read-Host "请选择模式 (1-4, 默认: 4)"
    $selectedMode = switch ($modeChoice) {
        "1" { "development" }
        "2" { "pm2" }
        "3" { "hybrid" }
        default { "auto" }
    }
    
    Write-Info "配置完成: 环境=$selectedEnv, 模式=$selectedMode" "MENU"
    return @{ Environment = $selectedEnv; Mode = $selectedMode; Interactive = $true }
}

# ============================================================================
# 主函数入口
# ============================================================================

function Main {
    # 处理帮助请求
    if ($Help) {
        Show-Help
        return
    }

    # 处理交互式菜单
    if ($ShowMenu) {
        $menuResult = Show-InteractiveMenu
        if ($null -eq $menuResult) { return }

        # 更新全局变量
        $script:ENV_NAME = $menuResult.Environment
        $script:START_MODE = $menuResult.Mode

        if ($menuResult.Mode -eq "check") {
            # 只进行系统检查，不启动服务
            Invoke-SystemCheck
            return
        }
    } else {
        # 如果没有通过菜单设置，尝试从配置系统读取默认值
        if ([string]::IsNullOrEmpty($ENV_NAME) -or [string]::IsNullOrEmpty($START_MODE)) {
            try {
                # 加载配置管理系统
                $configScript = Join-Path $PROJECT_ROOT "config.ps1"
                if (Test-Path $configScript) {
                    . $configScript

                    # 从配置系统读取默认值
                    if ([string]::IsNullOrEmpty($ENV_NAME)) {
                        $configEnv = Get-SystemConfig -ConfigKey "system.environment"
                        if (-not [string]::IsNullOrEmpty($configEnv)) {
                            $script:ENV_NAME = $configEnv
                        }
                    }

                    if ([string]::IsNullOrEmpty($START_MODE)) {
                        $configMode = Get-SystemConfig -ConfigKey "system.mode"
                        if (-not [string]::IsNullOrEmpty($configMode)) {
                            $script:START_MODE = $configMode
                        }
                    }
                }
            } catch {
                Write-Debug "无法从配置系统读取默认值: $($_.Exception.Message)" "MAIN"
            }
        }
    }

    # 显示启动信息
    Show-StartupBanner

    # 继续执行启动流程...
    Write-Info "启动流程开始..." "MAIN"
    Write-Debug "环境: $ENV_NAME, 模式: $START_MODE" "MAIN"

    if ($DryRun) {
        Write-Warning "模拟运行模式 - 不会实际执行操作" "MAIN"
    }

    # 执行启动流程
    $success = Invoke-StartupProcess

    if ($success) {
        Write-Success "🎉 启动完成！" "MAIN"
        Show-StartupSummary
    } else {
        Write-Error "❌ 启动失败" "MAIN"
        exit 1
    }
}

function Invoke-StartupProcess {
    # 1. 系统检查
    if (-not $SkipDependencyCheck) {
        if (-not (Invoke-SystemCheck)) {
            return $false
        }
    }

    # 2. 环境配置
    if (-not (Set-Environment $ENV_NAME)) {
        return $false
    }

    # 3. 启动服务
    if (-not (Invoke-StartupRouter)) {
        return $false
    }

    # 4. 健康检查
    if (-not $SkipHealthCheck) {
        if (-not (Invoke-HealthCheck)) {
            return $false
        }
    }

    return $true
}

function Show-StartupSummary {
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
    Write-Host "  🎉 启动成功！" -ForegroundColor Green
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
    Write-Host ""
    Write-Host "🌐 服务地址:" -ForegroundColor Yellow
    Write-Host "  • 后端API: http://localhost:$BackendPort" -ForegroundColor Cyan
    Write-Host "  • 前端界面: http://localhost:$FrontendPort" -ForegroundColor Magenta
    Write-Host "  • 健康检查: http://localhost:$BackendPort/health" -ForegroundColor Blue
    Write-Host ""
    Write-Host "📊 系统信息:" -ForegroundColor Yellow
    Write-Host "  • 环境: $ENV_NAME" -ForegroundColor Gray
    Write-Host "  • 模式: $START_MODE" -ForegroundColor Gray
    Write-Host "  • 启动时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
    Write-Host ""
    Write-Host "🔧 管理命令:" -ForegroundColor Yellow
    Write-Host "  • 查看PM2状态: pm2 list" -ForegroundColor White
    Write-Host "  • 查看日志: pm2 logs" -ForegroundColor White
    Write-Host "  • 停止服务: pm2 stop all" -ForegroundColor White
    Write-Host ""
    Write-Host "📊 监控命令:" -ForegroundColor Yellow
    Write-Host "  • 启动监控仪表板: .\monitor.ps1" -ForegroundColor Cyan
    Write-Host "  • 启用自动恢复监控: .\monitor.ps1 -EnableAutoRecovery" -ForegroundColor Cyan
    Write-Host "  • 集成监控: .\start.ps1 -ShowMenu (选择选项5)" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "🔧 恢复命令:" -ForegroundColor Yellow
    Write-Host "  • 执行健康检查: .\recovery.ps1" -ForegroundColor Green
    Write-Host "  • 执行自动恢复: .\recovery.ps1 -Mode recover" -ForegroundColor Green
    Write-Host "  • 启动恢复守护进程: .\recovery.ps1 -Mode daemon" -ForegroundColor Green
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
}

function Start-LogManagement {
    Clear-Host
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
    Write-Host "  日志管理系统" -ForegroundColor Green
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
    Write-Host ""

    while ($true) {
        Write-Host "📝 日志管理选项:" -ForegroundColor Yellow
        Write-Host "  [1] 查看最新日志" -ForegroundColor White
        Write-Host "  [2] 搜索日志内容" -ForegroundColor White
        Write-Host "  [3] 查看日志统计" -ForegroundColor White
        Write-Host "  [4] 清理日志文件" -ForegroundColor White
        Write-Host "  [5] 实时监控日志" -ForegroundColor White
        Write-Host "  [6] 归档旧日志" -ForegroundColor White
        Write-Host "  [0] 返回主菜单" -ForegroundColor Red
        Write-Host ""

        $choice = Read-Host "请输入选择 (0-6)"

        switch ($choice) {
            "1" {
                Write-Info "查看最新日志..." "LOG"
                if (Get-Command Show-LogEntries -ErrorAction SilentlyContinue) {
                    Show-LogEntries "all" "ALL" "" "24h" 50
                } else {
                    Write-Error "日志系统未加载，请检查logs.ps1文件"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "2" {
                $searchTerm = Read-Host "请输入搜索关键词"
                if ($searchTerm) {
                    Write-Info "搜索日志: $searchTerm" "LOG"
                    if (Get-Command Search-LogEntries -ErrorAction SilentlyContinue) {
                        Search-LogEntries $searchTerm "all" "ALL" "7d" 100
                    } else {
                        Write-Error "日志系统未加载，请检查logs.ps1文件"
                    }
                } else {
                    Write-Warning "搜索关键词不能为空"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "3" {
                Write-Info "生成日志统计..." "LOG"
                if (Get-Command Show-LogStatistics -ErrorAction SilentlyContinue) {
                    Show-LogStatistics "all" "7d"
                } else {
                    Write-Error "日志系统未加载，请检查logs.ps1文件"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "4" {
                Write-Warning "⚠️ 警告：此操作将清理日志文件"
                $confirm = Read-Host "确定要继续吗？将自动归档现有日志 (y/N)"
                if ($confirm -eq "y" -or $confirm -eq "Y") {
                    Write-Info "清理日志文件..." "LOG"
                    if (Get-Command Clear-LogFiles -ErrorAction SilentlyContinue) {
                        Clear-LogFiles "all" -Archive:$true -Force:$true
                    } else {
                        Write-Error "日志系统未加载，请检查logs.ps1文件"
                    }
                } else {
                    Write-Info "操作已取消" "LOG"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "5" {
                Write-Info "启动实时日志监控（按Ctrl+C退出）..." "LOG"
                if (Get-Command Start-LogTail -ErrorAction SilentlyContinue) {
                    Start-LogTail "all" "ALL"
                } else {
                    Write-Error "日志系统未加载，请检查logs.ps1文件"
                    Read-Host "按回车键继续"
                }
            }
            "6" {
                Write-Info "归档旧日志..." "LOG"
                if (Get-Command Remove-OldLogFiles -ErrorAction SilentlyContinue) {
                    Remove-OldLogFiles 30
                } else {
                    Write-Error "日志系统未加载，请检查logs.ps1文件"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "0" {
                return
            }
            default {
                Write-Warning "无效选择，请输入 0-6"
                Start-Sleep -Seconds 1
            }
        }

        Clear-Host
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
        Write-Host "  日志管理系统" -ForegroundColor Green
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
        Write-Host ""
    }
}

function Start-ConfigManagement {
    Clear-Host
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta
    Write-Host "  系统配置管理" -ForegroundColor Magenta
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta
    Write-Host ""

    # 检查配置管理系统是否可用
    if (-not (Get-Command Start-InteractiveConfig -ErrorAction SilentlyContinue)) {
        Write-Host "❌ 配置管理系统未加载，请检查config.ps1文件" -ForegroundColor Red
        Read-Host "按回车键返回主菜单"
        return
    }

    while ($true) {
        Write-Host "⚙️ 配置管理选项:" -ForegroundColor Yellow
        Write-Host "  [1] 交互式配置管理" -ForegroundColor White
        Write-Host "  [2] 查看当前配置" -ForegroundColor White
        Write-Host "  [3] 快速配置向导" -ForegroundColor White
        Write-Host "  [4] 配置备份管理" -ForegroundColor White
        Write-Host "  [5] 配置验证检查" -ForegroundColor White
        Write-Host "  [6] 同步配置到脚本" -ForegroundColor White
        Write-Host "  [0] 返回主菜单" -ForegroundColor Red
        Write-Host ""

        $choice = Read-Host "请输入选择 (0-6)"

        switch ($choice) {
            "1" {
                Write-Info "启动交互式配置管理..." "CONFIG"
                Start-InteractiveConfig
            }
            "2" {
                Write-Info "显示当前配置..." "CONFIG"
                if (Get-Command Show-ConfigList -ErrorAction SilentlyContinue) {
                    Show-ConfigList
                } else {
                    Write-Error "配置显示功能不可用"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "3" {
                Write-Info "启动快速配置向导..." "CONFIG"
                Start-QuickConfigWizard
            }
            "4" {
                Write-Info "配置备份管理..." "CONFIG"
                if (Get-Command Show-ConfigBackups -ErrorAction SilentlyContinue) {
                    Show-ConfigBackups
                    Write-Host ""
                    Write-Host "备份操作:" -ForegroundColor Yellow
                    Write-Host "  [1] 创建新备份"
                    Write-Host "  [2] 恢复备份"
                    Write-Host "  [0] 返回"

                    $backupChoice = Read-Host "请选择"
                    switch ($backupChoice) {
                        "1" {
                            if (Get-Command Backup-ConfigFile -ErrorAction SilentlyContinue) {
                                $backupPath = Backup-ConfigFile (Join-Path $PROJECT_ROOT "configs\system-config.json")
                                if ($backupPath) {
                                    Write-Host "✅ 配置备份成功: $([System.IO.Path]::GetFileName($backupPath))" -ForegroundColor Green
                                }
                            }
                        }
                        "2" {
                            $backupName = Read-Host "请输入备份文件名"
                            if ($backupName -and (Get-Command Restore-ConfigFile -ErrorAction SilentlyContinue)) {
                                $backupPath = Join-Path $PROJECT_ROOT "configs\backups\$backupName"
                                $success = Restore-ConfigFile $backupPath
                                if ($success) {
                                    Write-Host "✅ 配置恢复成功" -ForegroundColor Green
                                }
                            }
                        }
                    }
                } else {
                    Write-Error "配置备份功能不可用"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "5" {
                Write-Info "验证配置文件..." "CONFIG"
                if (Get-Command Validate-ConfigFile -ErrorAction SilentlyContinue) {
                    $isValid = Validate-ConfigFile
                    if ($isValid) {
                        Write-Host "✅ 配置文件验证通过" -ForegroundColor Green
                    } else {
                        Write-Host "❌ 配置文件验证失败，请检查日志" -ForegroundColor Red
                    }
                } else {
                    Write-Error "配置验证功能不可用"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "6" {
                Write-Info "同步配置到其他脚本..." "CONFIG"
                if (Get-Command Sync-ConfigToScripts -ErrorAction SilentlyContinue) {
                    Sync-ConfigToScripts
                    Write-Host "✅ 配置同步完成" -ForegroundColor Green
                } else {
                    Write-Error "配置同步功能不可用"
                }
                Write-Host ""
                Read-Host "按回车键继续"
            }
            "0" {
                return
            }
            default {
                Write-Warning "无效选择，请输入 0-6"
                Start-Sleep -Seconds 1
            }
        }

        Clear-Host
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta
        Write-Host "  系统配置管理" -ForegroundColor Magenta
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Magenta
        Write-Host ""
    }
}

function Start-QuickConfigWizard {
    Write-Host ""
    Write-Host "🧙‍♂️ 快速配置向导" -ForegroundColor Cyan
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
    Write-Host ""

    # 环境配置
    Write-Host "1. 选择运行环境:" -ForegroundColor Yellow
    Write-Host "   [1] 开发环境 (development)"
    Write-Host "   [2] 生产环境 (production)"
    $envChoice = Read-Host "请选择 (1-2)"

    $environment = switch ($envChoice) {
        "1" { "development" }
        "2" { "production" }
        default { "development" }
    }

    # 启动模式配置
    Write-Host ""
    Write-Host "2. 选择启动模式:" -ForegroundColor Yellow
    Write-Host "   [1] 自动模式 (auto)"
    Write-Host "   [2] 开发模式 (development)"
    Write-Host "   [3] PM2模式 (pm2)"
    $modeChoice = Read-Host "请选择 (1-3)"

    $mode = switch ($modeChoice) {
        "1" { "auto" }
        "2" { "development" }
        "3" { "pm2" }
        default { "auto" }
    }

    # 端口配置
    Write-Host ""
    Write-Host "3. 配置端口:" -ForegroundColor Yellow
    $backendPort = Read-Host "后端端口 (默认: 8001)"
    if (-not $backendPort) { $backendPort = 8001 }

    $frontendPort = Read-Host "前端端口 (默认: 3000)"
    if (-not $frontendPort) { $frontendPort = 3000 }

    # 应用配置
    Write-Host ""
    Write-Host "4. 应用配置向导完成，正在保存..." -ForegroundColor Green

    # 保存配置
    if (Get-Command Set-SystemConfig -ErrorAction SilentlyContinue) {
        Set-SystemConfig "system.environment" $environment
        Set-SystemConfig "system.mode" $mode
        Set-SystemConfig "ports.backend" ([int]$backendPort)
        Set-SystemConfig "ports.frontend" ([int]$frontendPort)

        # 同步配置
        if (Get-Command Sync-ConfigToScripts -ErrorAction SilentlyContinue) {
            Sync-ConfigToScripts
        }

        Write-Host "✅ 配置保存成功！" -ForegroundColor Green
        Write-Host ""
        Write-Host "配置摘要:" -ForegroundColor Cyan
        Write-Host "  环境: $environment" -ForegroundColor White
        Write-Host "  模式: $mode" -ForegroundColor White
        Write-Host "  后端端口: $backendPort" -ForegroundColor White
        Write-Host "  前端端口: $frontendPort" -ForegroundColor White
    } else {
        Write-Host "❌ 配置保存失败，配置管理功能不可用" -ForegroundColor Red
    }

    Write-Host ""
    Read-Host "按回车键继续"
}

function Show-StartupBanner {
    if (-not $Quiet) {
        Clear-Host
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
        Write-Host "  $SCRIPT_NAME v$SCRIPT_VERSION" -ForegroundColor Cyan
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
        Write-Host ""
        Write-Success "🚀 启动系统初始化..."
        Write-Host ""
        Write-Host "📋 配置信息:" -ForegroundColor Blue
        Write-Host "  • 环境: $ENV_NAME" -ForegroundColor Gray
        Write-Host "  • 模式: $START_MODE" -ForegroundColor Gray
        Write-Host "  • 后端端口: $BackendPort" -ForegroundColor Gray
        Write-Host "  • 前端端口: $FrontendPort" -ForegroundColor Gray
        Write-Host "  • 超时时间: $TimeoutSeconds 秒" -ForegroundColor Gray
        Write-Host ""
    }
}

# ============================================================================
# 系统检查和依赖验证
# ============================================================================

function Test-Prerequisites {
    Write-Info "🔍 检查系统先决条件..." "CHECK"
    $issues = @()

    # 检查Node.js
    try {
        $nodeVersion = node --version
        $requiredNodeVersion = "v18.0.0"

        if ([version]($nodeVersion -replace 'v','') -lt [version]($requiredNodeVersion -replace 'v','')) {
            $issues += "Node.js版本需要 >= $requiredNodeVersion，当前版本: $nodeVersion"
        } else {
            Write-Success "✅ Node.js检查通过: $nodeVersion" "CHECK"
        }
    } catch {
        $issues += "Node.js未安装或不在PATH中"
    }

    # 检查npm
    try {
        $npmVersion = npm --version
        Write-Success "✅ npm检查通过: v$npmVersion" "CHECK"
    } catch {
        $issues += "npm未安装或不在PATH中"
    }

    # 检查PM2（如果需要）
    if ($START_MODE -in @("pm2", "hybrid", "auto")) {
        try {
            $pm2Version = pm2 --version
            Write-Success "✅ PM2检查通过: v$pm2Version" "CHECK"
        } catch {
            if ($START_MODE -eq "pm2") {
                $issues += "PM2未安装，生产模式需要PM2"
            } else {
                Write-Warning "⚠️ PM2未安装，将使用开发模式" "CHECK"
                $script:START_MODE = "development"
            }
        }
    }

    # 检查项目结构
    $requiredDirs = @($BACKEND_DIR, $FRONTEND_DIR, $CONFIG_DIR)
    foreach ($dir in $requiredDirs) {
        if (-not (Test-Path $dir)) {
            $issues += "缺少必要目录: $dir"
        }
    }

    # 检查关键文件
    $requiredFiles = @(
        (Join-Path $BACKEND_DIR "package.json"),
        (Join-Path $FRONTEND_DIR "package.json")
    )
    foreach ($file in $requiredFiles) {
        if (-not (Test-Path $file)) {
            $issues += "缺少必要文件: $file"
        }
    }

    if ($issues.Count -gt 0) {
        Write-Error "❌ 系统检查失败:" "CHECK"
        foreach ($issue in $issues) {
            Write-Error "  • $issue" "CHECK"
        }
        return $false
    }

    Write-Success "✅ 所有先决条件检查通过" "CHECK"
    return $true
}

function Test-PortAvailability {
    param([int]$Port, [string]$Service)

    try {
        $connection = Test-NetConnection -ComputerName "localhost" -Port $Port -WarningAction SilentlyContinue
        if ($connection.TcpTestSucceeded) {
            Write-Warning "⚠️ 端口 $Port 已被占用 ($Service)" "PORT"

            if ($Force) {
                Write-Info "🔄 强制模式：尝试释放端口 $Port" "PORT"
                Stop-ProcessOnPort $Port
                return $true
            } else {
                Write-Error "❌ 端口 $Port 被占用，使用 -Force 参数强制启动" "PORT"
                return $false
            }
        } else {
            Write-Success "✅ 端口 $Port 可用 ($Service)" "PORT"
            return $true
        }
    } catch {
        Write-Debug "端口检查异常: $($_.Exception.Message)" "PORT"
        return $true  # 假设可用
    }
}

function Stop-ProcessOnPort {
    param([int]$Port)

    try {
        $processes = Get-NetTCPConnection -LocalPort $Port -ErrorAction SilentlyContinue |
                    Select-Object -ExpandProperty OwningProcess |
                    Sort-Object -Unique

        foreach ($pid in $processes) {
            if ($pid -and $pid -ne 0) {
                $process = Get-Process -Id $pid -ErrorAction SilentlyContinue
                if ($process) {
                    Write-Warning "🔄 终止进程: $($process.ProcessName) (PID: $pid)" "PORT"
                    Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
                    Start-Sleep -Seconds 2
                }
            }
        }
    } catch {
        Write-Debug "终止端口进程时出错: $($_.Exception.Message)" "PORT"
    }
}

# ============================================================================
# 环境和配置管理
# ============================================================================

function Set-Environment {
    param([string]$TargetEnvironment)

    Write-Info "🔄 配置环境: $TargetEnvironment" "ENV"

    if ($DryRun) {
        Write-Info "🔍 [模拟] 环境切换到: $TargetEnvironment" "ENV"
        return $true
    }

    # 调用环境切换脚本
    $switchEnvScript = Join-Path $PROJECT_ROOT "switch-env.ps1"
    if (Test-Path $switchEnvScript) {
        try {
            & $switchEnvScript -Environment $TargetEnvironment -VerboseOutput:$VerboseOutput
            Write-Success "✅ 环境配置完成: $TargetEnvironment" "ENV"
            return $true
        } catch {
            Write-Error "❌ 环境配置失败: $($_.Exception.Message)" "ENV"
            return $false
        }
    } else {
        Write-Warning "⚠️ 环境切换脚本不存在，跳过环境配置" "ENV"
        return $true
    }
}

# ============================================================================
# 启动模式路由
# ============================================================================

function Invoke-StartupRouter {
    Write-Info "🚀 启动模式路由: $START_MODE" "ROUTER"

    # 智能模式选择
    if ($START_MODE -eq "auto") {
        $START_MODE = Get-OptimalStartMode
        Write-Info "🤖 自动选择启动模式: $START_MODE" "ROUTER"
    }

    switch ($START_MODE) {
        "development" {
            return Start-DevelopmentMode
        }
        "pm2" {
            return Start-PM2Mode
        }
        "hybrid" {
            return Start-HybridMode
        }
        default {
            Write-Error "❌ 未知启动模式: $START_MODE" "ROUTER"
            return $false
        }
    }
}

function Get-OptimalStartMode {
    # 智能选择最佳启动模式
    if ($ENV_NAME -eq "production") {
        return "pm2"
    } elseif (Get-Command "pm2" -ErrorAction SilentlyContinue) {
        return "hybrid"  # 开发环境但有PM2，使用混合模式
    } else {
        return "development"
    }
}

function Start-DevelopmentMode {
    Write-Info "🚀 启动开发模式..." "DEV"

    if ($DryRun) {
        Write-Info "🔍 [模拟] 开发模式启动" "DEV"
        return $true
    }

    # 调用现有的开发启动脚本
    $devScript = Join-Path $PROJECT_ROOT "start-dev.ps1"
    if (Test-Path $devScript) {
        Write-Info "📡 使用现有开发启动脚本" "DEV"
        & $devScript
        return $true
    } else {
        # 直接启动开发服务
        return Start-DevelopmentServices
    }
}

function Start-PM2Mode {
    Write-Info "🏭 启动PM2模式..." "PM2"

    if ($DryRun) {
        Write-Info "🔍 [模拟] PM2模式启动" "PM2"
        return $true
    }

    # 调用现有的PM2部署脚本
    $pm2Script = Join-Path $PROJECT_ROOT "deploy-pm2.ps1"
    if (Test-Path $pm2Script) {
        Write-Info "⚙️ 使用现有PM2部署脚本" "PM2"
        & $pm2Script -Environment $ENV_NAME
        return $true
    } else {
        # 直接启动PM2服务
        return Start-PM2Services
    }
}

function Start-HybridMode {
    Write-Info "🔀 启动混合模式..." "HYBRID"

    if ($DryRun) {
        Write-Info "🔍 [模拟] 混合模式启动" "HYBRID"
        return $true
    }

    # 后端使用PM2，前端使用开发模式
    Write-Info "📡 启动后端PM2服务..." "HYBRID"
    $backendResult = Start-PM2Services

    if ($backendResult) {
        Write-Info "🎨 启动前端开发服务..." "HYBRID"
        Start-FrontendDevelopment
    }

    return $backendResult
}

function Invoke-SystemCheck {
    Write-Info "🔍 开始系统检查..." "CHECK"

    $checkResult = Test-Prerequisites
    if (-not $checkResult) {
        return $false
    }

    # 检查端口可用性
    $portCheckResult = $true
    $portCheckResult = $portCheckResult -and (Test-PortAvailability $BackendPort "后端服务")
    $portCheckResult = $portCheckResult -and (Test-PortAvailability $FrontendPort "前端服务")

    if (-not $portCheckResult) {
        return $false
    }

    Write-Success "✅ 系统检查完成" "CHECK"
    return $true
}

# ============================================================================
# 具体服务启动函数
# ============================================================================

function Start-DevelopmentServices {
    Write-Info "🚀 直接启动开发服务..." "DEV"

    # 启动后端开发服务
    Write-Info "📡 启动后端开发服务..." "DEV"
    $backendJob = Start-Job -ScriptBlock {
        param($BackendDir)
        Set-Location $BackendDir
        npm run dev
    } -ArgumentList $BACKEND_DIR

    Start-Sleep -Seconds 3

    # 启动前端开发服务
    Write-Info "🎨 启动前端开发服务..." "DEV"
    $frontendJob = Start-Job -ScriptBlock {
        param($FrontendDir)
        Set-Location $FrontendDir
        npm run dev
    } -ArgumentList $FRONTEND_DIR

    Write-Success "✅ 开发服务启动完成" "DEV"
    return $true
}

function Start-PM2Services {
    Write-Info "🏭 启动PM2服务..." "PM2"

    try {
        # 构建项目（如果需要）
        if (-not $SkipBuild) {
            Write-Info "🔨 构建后端项目..." "PM2"
            Set-Location $BACKEND_DIR
            npm run build
            Set-Location $PROJECT_ROOT
        }

        # 启动PM2服务
        Write-Info "⚙️ 启动PM2进程..." "PM2"
        pm2 start ecosystem.config.js --env $ENV_NAME

        Write-Success "✅ PM2服务启动完成" "PM2"
        return $true
    } catch {
        Write-Error "❌ PM2服务启动失败: $($_.Exception.Message)" "PM2"
        return $false
    }
}

function Start-FrontendDevelopment {
    Write-Info "🎨 启动前端开发服务..." "FRONTEND"

    $frontendJob = Start-Job -ScriptBlock {
        param($FrontendDir)
        Set-Location $FrontendDir
        npm run dev
    } -ArgumentList $FRONTEND_DIR

    Write-Success "✅ 前端开发服务启动完成" "FRONTEND"
    return $true
}

# ============================================================================
# 健康检查模块
# ============================================================================

function Invoke-HealthCheck {
    Write-Info "💚 开始健康检查..." "HEALTH"

    $startTime = Get-Date
    $isHealthy = $false

    Write-Info "⏳ 等待服务启动..." "HEALTH"

    while (((Get-Date) - $startTime).TotalSeconds -lt $TimeoutSeconds) {
        Start-Sleep -Seconds $HEALTH_CHECK_INTERVAL

        if (Test-ServiceHealth) {
            $isHealthy = $true
            break
        }

        Write-Debug "等待服务响应..." "HEALTH"
    }

    if ($isHealthy) {
        Write-Success "✅ 健康检查通过" "HEALTH"
        return $true
    } else {
        Write-Error "❌ 健康检查超时" "HEALTH"
        return $false
    }
}

function Test-ServiceHealth {
    try {
        # 检查后端健康状态
        $response = Invoke-RestMethod -Uri "http://localhost:$BackendPort/health" -Method Get -TimeoutSec 5
        if ($response.status -eq "healthy") {
            Write-Success "✅ 后端服务健康" "HEALTH"
            return $true
        }
    } catch {
        Write-Debug "后端健康检查失败: $($_.Exception.Message)" "HEALTH"
    }

    return $false
}

function Test-FrontendHealth {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:$FrontendPort" -Method Get -TimeoutSec 5
        if ($response.StatusCode -eq 200) {
            Write-Success "✅ 前端服务健康" "HEALTH"
            return $true
        }
    } catch {
        Write-Debug "前端健康检查失败: $($_.Exception.Message)" "HEALTH"
    }

    return $false
}

# ============================================================================
# 错误处理和清理
# ============================================================================

function Stop-AllServices {
    Write-Info "🛑 停止所有服务..." "CLEANUP"

    try {
        # 停止PM2服务
        pm2 stop all 2>$null
        pm2 delete all 2>$null

        # 停止开发服务作业
        Get-Job | Stop-Job
        Get-Job | Remove-Job

        Write-Success "✅ 服务清理完成" "CLEANUP"
    } catch {
        Write-Warning "⚠️ 清理过程中出现问题: $($_.Exception.Message)" "CLEANUP"
    }
}

# ============================================================================
# 监控仪表板集成
# ============================================================================

function Start-MonitorDashboard {
    Write-Info "🚀 启动监控仪表板..." "MONITOR"

    # 检查monitor.ps1是否存在
    $monitorScript = Join-Path $PROJECT_ROOT "monitor.ps1"
    if (-not (Test-Path $monitorScript)) {
        Write-Error "❌ 监控脚本不存在: $monitorScript" "MONITOR"
        Write-Host "请确保monitor.ps1文件在项目根目录中。" -ForegroundColor Yellow
        Write-Host "按任意键返回主菜单..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        return
    }

    try {
        # 启动监控脚本
        Write-Info "📊 正在启动实时监控..." "MONITOR"
        $monitorParams = @{
            BackendPort = $BackendPort
            FrontendPort = $FrontendPort
        }

        if ($EnableAutoRecovery) {
            $monitorParams.EnableAutoRecovery = $true
            Write-Info "🔧 自动恢复功能已启用" "MONITOR"
        }

        & $monitorScript @monitorParams
    } catch {
        Write-Error "❌ 监控仪表板启动失败: $($_.Exception.Message)" "MONITOR"
        Write-Host "按任意键返回主菜单..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
}

function Start-ApiManagement {
    Clear-Host
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
    Write-Host "  API接口管理系统" -ForegroundColor Blue
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
    Write-Host ""

    # 检查API管理系统是否可用
    if (-not (Get-Command Start-InteractiveApiManager -ErrorAction SilentlyContinue)) {
        Write-Host "❌ API管理系统未加载，请检查api.ps1文件" -ForegroundColor Red
        Read-Host "按回车键返回主菜单"
        return
    }

    while ($true) {
        Write-Host "🔌 API管理选项:" -ForegroundColor Yellow
        Write-Host "  [1] 交互式API管理" -ForegroundColor White
        Write-Host "  [2] 自动发现API" -ForegroundColor White
        Write-Host "  [3] API健康检查" -ForegroundColor White
        Write-Host "  [4] API监控报告" -ForegroundColor White
        Write-Host "  [5] API统计分析" -ForegroundColor White
        Write-Host "  [6] 生成API文档" -ForegroundColor White
        Write-Host "  [0] 返回主菜单" -ForegroundColor Red
        Write-Host ""

        $choice = Read-Host "请输入选择 (0-6)"

        switch ($choice) {
            "1" {
                Write-Info "启动交互式API管理..." "API"
                Start-InteractiveApiManager
            }
            "2" {
                Write-Info "开始API自动发现..." "API"
                $discovered = Invoke-ApiDiscovery
                Write-Host "发现了 $($discovered.Count) 个新API" -ForegroundColor Green
                Read-Host "按回车键继续"
            }
            "3" {
                Write-Info "执行API健康检查..." "API"
                Show-ApiHealthStatus
                Read-Host "按回车键继续"
            }
            "4" {
                Write-Info "执行API监控..." "API"
                $results = Invoke-ApiMonitoring
                Write-Host "监控完成，检查了 $($results.Count) 个API" -ForegroundColor Green
                Read-Host "按回车键继续"
            }
            "5" {
                Write-Info "显示API统计..." "API"
                Show-ApiStatistics
                Read-Host "按回车键继续"
            }
            "6" {
                Write-Info "生成API文档..." "API"
                Generate-ApiDocumentation
                Read-Host "按回车键继续"
            }
            "0" {
                Write-Info "返回主菜单..." "API"
                break
            }
            default {
                Write-Host "❌ 无效选择，请重试" -ForegroundColor Red
                Start-Sleep -Seconds 2
            }
        }

        Clear-Host
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
        Write-Host "  API接口管理系统" -ForegroundColor Blue
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Blue
        Write-Host ""
    }
}

function Add-MonitorOption {
    param([string]$Message)

    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
    Write-Host "  $Message" -ForegroundColor Green
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Green
    Write-Host ""
    Write-Host "📊 监控选项:" -ForegroundColor Yellow
    Write-Host "  • 启动监控仪表板: .\monitor.ps1" -ForegroundColor Cyan
    Write-Host "  • 集成监控启动: .\start.ps1 -ShowMenu 选择选项5" -ForegroundColor Cyan
    Write-Host ""
}

# 注册清理函数
Register-EngineEvent PowerShell.Exiting -Action {
    Stop-AllServices
}

# 执行主函数
Main
